# Forma parte de una pequeña practica para el trabajo, para la web de 41basica. 
# Es un generador de test en PDF cogiendo las preguntas de una base de datos. 
# -->>>>> Para que funcione hace falta el archivo PHP de conexion 