<?php
require "plantilla_retro.php";
require "plantilla_test.php";
require "plantilla_respuestas.php";

imprimirRetro ($retro);
imprimirTest ($test);
imprimirRespuestas ($respu);


